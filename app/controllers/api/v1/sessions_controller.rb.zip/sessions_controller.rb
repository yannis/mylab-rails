# class API::V1::SessionsController < Devise::SessionsController

#   skip_before_filter :authenticate_user_from_token!
#   # skip_before_action :authenticate_api_v1_user!

#   respond_to :html, :json

#   def create
#     Rails.logger.debug "CREATE called"
#     super do |user|
#       if request.format.json?
#         data = {
#           token: user.authentication_token,
#           email: user.email
#         }
#         render json: data, status: 201 and return
#       end
#     end
#   end
# end
